# -*- coding: utf-8 -*-
get = lambda : ''
