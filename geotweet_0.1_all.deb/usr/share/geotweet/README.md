## #OSINT #GEOLOCATION #TWITTER #INSTAGRAM

![alt tag](https://pbs.twimg.com/media/B96X3erCcAErsyf.jpg:large)

##Social engineering tool for human hacking
Another way to use Twitter and instagram.
Geotweet is an osint application that allows you to track tweets and instagram and trace geographical locations and then export to google maps.
Allows you to search on tags, world zones and user (info and timeline)

## Requirements
* Python 2.7
* PyQt4, tweepy, geopy, ca_certs_locater, python-instagram

###--------------------------------------------------------------------------
###          Works on Linux, Windows, Mac OSX, BSD
###--------------------------------------------------------------------------

## Installation example of Backbox or kali

``` shell
git clone https://github.com/Pinperepette/Geotweet_GUI.git
cd Geotweet_GUI
chmod +x Geotweet.py
sudo apt-get install python-pip
sudo pip install -r requirements.txt
python ./Geotweet.py
```
##  -     -     -     -     -     -     -     -     -

## VIDEO TUTORIAL 

[![VIDEO TUTORIAL](https://farm6.staticflickr.com/5745/20334266814_53eb4cf1f4_b.jpg)](https://www.youtube.com/watch?v=tB_p7gVWsks)

##  -     -     -     -     -     -     -     -     -
<dl>
  <dt>For more information</dt>
  </dl> 
[Official site](http://geotweet.altervista.org)
